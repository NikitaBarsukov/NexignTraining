create function interval_pl_timestamp(interval, timestamp without time zone) returns timestamp without time zone
IMMUTABLE
LANGUAGE SQL
AS $$
select $2 + $1
$$;
